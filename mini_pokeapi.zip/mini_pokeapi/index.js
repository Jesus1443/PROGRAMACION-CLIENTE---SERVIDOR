//Punto de entrada o ejecutable
const App = require('./src/app');
const app = new App();

app.start();