const {Router} = require('express');

const router = Router();

router.get('/seed', require('../controllers/pokemon').pokemonSeeder);
router.get('/random', require('../controllers/pokemon').randomPokemon);
router.get('/:id', require('../controllers/pokemon').PokemonByid);
router.get('/', require('../controllers/pokemon').ShowPokemons);

module.exports = router;


