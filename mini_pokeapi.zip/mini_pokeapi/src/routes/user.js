//Rutas de los Endpoints
const {Router} = require('express');

const router = Router();
//http:localhost:3000/user/
router.get('/', require('../controllers/user').showUsers);
//http:localhost:3000/user/1
router.get('/:id', require('../controllers/user').viewUser);
router.post('/', require('../controllers/user').createUser);
router.delete('/:id', require('../controllers/user').removeUser);
router.put('/:id', require('../controllers/user').updateUser);
router.post('/login', require('../controllers/user').loginUser);

module.exports = router;