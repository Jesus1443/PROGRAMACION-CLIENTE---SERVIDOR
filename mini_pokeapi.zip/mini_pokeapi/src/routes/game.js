const {Router} = require('express');
const router = Router();

router.get('/win/:id', require('../controllers/game').win);

router.get('/lose/:id', require('../controllers/game').lose);

router.get('/view', require('../controllers/game').viewGame);

    


module.exports = router;