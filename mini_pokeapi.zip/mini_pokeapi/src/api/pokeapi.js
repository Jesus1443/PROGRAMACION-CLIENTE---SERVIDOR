const getPokemons = async () => {

    const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=151`);
    const { results } = await response.json();

    const pokemons = results.map((pokemon, index) => {
        return { ...pokemon, image: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/${index + 1}.svg` }
    });

    return pokemons;

}

module.exports = {
    getPokemons
};