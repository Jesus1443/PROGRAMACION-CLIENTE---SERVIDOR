//importar informacion que exista en el archivo .env
require('dotenv').config();

const env = {
    dbPort: process.env.DB_PORT,
    dbName: process.env.DB_NAME,
    dbUsername: process.env.DB_USERNAME,
    dbPassword: process.env.DB_PASSWORD,
    port: process.env.PORT
}



module.exports = env;