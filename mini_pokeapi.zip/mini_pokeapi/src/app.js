//Estructura basica de la aplicación
const express = require('express')
const env = require('./config/environment');
const cors = require('cors');

class App {
    constructor() {
        this.app = express();
        this.port = env.port;
        this.middlewares();
        this.routes();
    }

    middlewares() {
        this.app.use(cors());
        this.app.use(express.json());
    }

    routes() {
        //http://localhost:3000/
        this.app.get('/', (req, res) => {
            res.send('Hello world!');
        });
        //http://localhost:3000/user
        this.app.use('/user', require('./routes/user'));

        //http://localhost:3000/pokemon
        this.app.use('/pokemon', require('./routes/pokemon'));
        //http://localhost:3000/game
        this.app.use('/game', require('./routes/game'));
    }


    start() {
        this.app.listen(this.port, () => {
            console.log(`Server is running on port ${this.port}`);
        })
    }
}

module.exports = App;