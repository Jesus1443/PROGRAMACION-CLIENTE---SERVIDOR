//Acciones de los Endpoints
const { request, response } = require('express');
const bcrypt = require('bcrypt');
const userQueries = require('../models/user');
const pool = require('../config/dbConnection');


const saltRounds = 10;

const showUsers = async (req = request, res = response) => {
    
    let conn; 
    try {
        conn = await pool.getConnection();
        const users = await conn.query(userQueries.users.show);
        res.send(users);
    }catch (err) {
        res.status(500).send(err);
    }finally{
        if (conn) conn.end();
    }
};

const viewUser = async (req = request, res = response) => {
    let conn;
    try {
        const { id } = req.params;

        if (isNaN(Number(id))) {
            res.status(400).send("The id is not a number");
            return;
        }

        conn = await pool.getConnection();
        const user = await conn.query(userQueries.users.view, [id]);

        if (user.length === 0) {
            res.status(404).send("User not found");
            return;
        }

        res.send(user[0]); // enviamos solo el objeto
    } catch (err) {
        res.status(500).send(err);
    } finally {
        if (conn) conn.end();
    }
};
 

const createUser = async (req = request, res = response) => {
    const { name, lastname, email, password } = req.body;

    if (!name || !lastname || !email || !password) {
        res.status(400).send("Missing parameters");
        return;
    }

    if (password.length < 6) {
        res.status(400).send("Password must be at least 6 characters");
        return;
    }

    let conn;
    try {
        conn = await pool.getConnection();
        const userExist = await conn.query(userQueries.users.verifyEmail, [email]);

        if (userExist.length > 0) {
            res.status(400).send("Email already exists");
            return;
        }

        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const userCreated = await conn.query(userQueries.users.create, [name, lastname, email, hashedPassword]);

        if (userCreated.affectedRows === 0) {
            res.status(500).send("User not created");
            return;
        }

        res.status(201).send("User created successfully");
    } catch (err) {
        res.status(500).send(err);
    } finally {
        if (conn) conn.end();
    }
};



const removeUser = async(req = request, res = response) => {
    const {id} = req.params;

    if (isNaN(Number(id))) {
        res.status(400).send("The id is not a number");
        return;
        }

       let conn;
    try {
        conn = await pool.getConnection();
        const userExists = conn.query(userQueries.users.view, [id]);

        if(!userExists) {
            res.status(400).send("User not found");
            return;
        }
        const userDeleted = await conn.query(userQueries.users.delete, [id]);

        if (userDeleted.affectedRows === 0){
            res.status(500).send("User cannot be deleted");
            return;
        }

        res.send("User deleted");
        
    } catch (err) {
        res.status(500).send(err);
    } finally {
        if (conn) conn.end();
    }
}


const updateUser = async (req = request, res = response) => {
    const {id} = req.params;
    
    
    if (isNaN(Number(id))) {
        res.status(400).send("Esto no es un numero");
        return;
    }

    let conn;

    try {
        conn = await pool.getConnection();
        const [user] = await conn.query(userQueries.users.view, [id]);

        if (!user){
        res.status(404).send("Usuario no encontrado");
        return;
        }
        const {name, lastname, email, password} = req.body;

        let hashedPassword;

        if (password) {
            hashedPassword = await bcrypt.hash(password,saltRounds);
        } else {
            hashedPassword= user.password;
        }

        const userToUpdate = {
        
        name: name || user.name,
        lastname: lastname || user.lastname, 
        email: email || user.email, 
        password: hashedPassword 
        };

        const userUpdate = await conn.query(userQueries.users.update, [
            userToUpdate.name,
            userToUpdate.lastname,
            userToUpdate.email,
            userToUpdate.password,
            id
        ]);

        if (userUpdate.affectedRows === 0) {
            res.status(500).send("No se pudo actualizar el usuario");
            return;
        }
        res.send({msg: "Usuario actualizado", user: userToUpdate});
    } catch (err) {
        console.log(err);
        res.status(500).send("error");
    } finally {
        if (conn) conn.end();
    }
    

    
}

const loginUser = async (req = request, res = response) => {
    const {email, password} = req.body;

    if(!email || !password) {
        res.status(400).send("Missing parameters");
        return;
    }

    let conn;
    try {
        conn = await pool.getConnection();
        const [user] = await conn.query(userQueries.users.viewByEmail, [email]);

        if (!user){
        res.status(404).send("Usuario no encontrado");
        return;
        }
        
        const validPassword = await bcrypt.compare(password, user.password);
       

        if (!validPassword) {
            res.status(401).send("Invalid user or password");
            return;
        }
        
        delete user.password;

        res.status(200).send(user);

        } catch (err) {
            res.status(500).send(err);
        } finally {
            if (conn) conn.end();
        }
    
}



module.exports = {
    showUsers,
    viewUser,
    createUser,
    removeUser,
    updateUser,
    loginUser
};
