const { request, response } = require('express');
const pokeapi = require('../api/pokeapi');
const pool = require('../config/dbConnection');
const { pokemonQuery } = require('../models/pokemon');

const pokemonSeeder = async(req = request, res = response) => {
    const Pokemons = await pokeapi.getPokemons();

    let conn;

    try{
        conn =  await pool.getConnection();
        //Truncate table pokemons
        await conn.query('SET FOREIGN_KEY_CHECKS = 0'); 
        await conn.query('TRUNCATE TABLE pokemons');
        await conn.query('SET FOREIGN_KEY_CHECKS = 1');


        Pokemons.forEach( async(pokemon) => {
            await conn.query(pokemonQuery.add, [pokemon.name, pokemon.image]);
        });
        res.send("Pokemons added to database");
    }catch(error){
        res.status(500).send(error);
    }finally{
        if(conn) conn.end();
    }
};

const randomPokemon = async(req = request, res = response) => {
    let conn;

    try{
        conn =  await pool.getConnection();
        const pokemons = await conn.query(pokemonQuery.random);

        if(pokemons.length === 0){
            res.status(500).send("No pokemons found");  
        }

        res.send(pokemons);

    }catch(err){
        res.status(500).send(err);
    }finally{
        if(conn) conn.end();
    }
};

const PokemonByid = async(req = request, res = response) => {
    const {id} = req.params;
    let conn;

    try{
        conn =  await pool.getConnection();
        const pokemon = await conn.query(pokemonQuery.view, [id]);

        if(!id || isNaN(id)){
            res.status(400).send("Invalid id");
        }
        res.send(pokemon);

    }catch(err){
        res.status(500).send(err);
    }finally{
        if(conn) conn.end();
    }
}

const ShowPokemons = async(req = request, res = response) => {
    let conn;

    try{
        conn =  await pool.getConnection();
        const pokemons = await conn.query(pokemonQuery.show);
        res.send(pokemons);
    }catch(err){
        res.status(500).send(err);
    }finally{
        if(conn) conn.end();
    }    
};

module.exports = {
    pokemonSeeder,
    randomPokemon,
    PokemonByid,
    ShowPokemons
};