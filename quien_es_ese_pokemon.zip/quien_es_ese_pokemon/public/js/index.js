const playBtn = document.querySelector('#play');
const choices = document.querySelector('#choices');
const main = document.querySelector('main');
const pokemonImage = document.querySelector('#pokemon-image');
const textOverlay = document.querySelector('#text-overlay');

let gameData;

const revealPokemon = () => {
  main.classList.add('revealed');
  textOverlay.textContent = gameData.correctAnswer.name;
}

const showSilouette = () => {
  main.classList.remove('fetching');
  pokemonImage.src = gameData.correctAnswer.image;
  console.log(gameData.correctAnswer);
};

const displayChoices = () => {
  const {pokemonChoices} = gameData;
  const choicesHTML = pokemonChoices.map(pokemon =>  {
    return `<button data-name="${pokemon.name}">${pokemon.name}</button>`; 
  }).join('');
  //console.log(choicesHTML);
  choices.innerHTML = choicesHTML;
};

const resetImage = () => {
  pokemonImage.src = 'https://res.cloudinary.com/dzynqn10l/image/upload/v1633196610/Msc/pokeball_zeoqii.webp';
  main.classList.remove('revealed');
}

const fetchData = async () => {
    resetImage();
    gameData = await window.getPokeData();
    showSilouette();
    displayChoices();
 
};

playBtn.addEventListener('click', fetchData); 

choices.addEventListener('click', (e) => {
  const {name} = e.target.dataset;
  const resultClass = name === gameData.correctAnswer.name ? 'correct' : 'incorrect';
  e.target.classList.add(resultClass);
  revealPokemon();
});